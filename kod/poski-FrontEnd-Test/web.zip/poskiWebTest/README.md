# poskiWebTest
## Složky
- Složka "web" - První děláno v pure css (jelikož jsem byl v posledních dnech na něj docela zvyklý z SvelteKit meta frameworku)
- Složka "web2", pro přehlednost jsem to převedl po dopsání všeho css do scss, 
- css není moc optimalizováno a určitě je tam dost stylů které jsou navíc.
- Animace jsou jak na kartách tak i na lupě a burger menu. 
## JS: 
- do console se vypisuje vše co by se mělo délka,výška,kliknutí, a ostatní,
- zavíraní nav reaguje na escape a kliknutí vedle
- Někde jak u class tak v JS používám angličtinu s češtinou, kóduju většinou pouze v angličtině, pro tento test jsem se snažil nějaké classy a let dát i do češtiny.
